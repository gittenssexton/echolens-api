from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List
from astroquery.gaia import Gaia
from astroquery.irsa import Irsa
from astroquery.mast import Observations
from astropy.coordinates import SkyCoord
import astropy.units as u
import pandas as pd

app = FastAPI()

# CORS and Static
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory="static"), name="static")

class Star(BaseModel):
    name: str
    distance: float
    ra: float
    dec: float
    w1m: float = None
    w2m: float = None
    w3m: float = None
    w4m: float = None
    anomaly_score: float = 0.0
    lightcurve_score: float = 0.0
    suspicion_index: float = 0.0

def fetch_wise_data(ra, dec):
    coord = SkyCoord(ra=ra*u.degree, dec=dec*u.degree, frame='icrs')
    try:
        result = Irsa.query_region(coord, catalog='allwise_p3as_psd', spatial='Cone', radius=5*u.arcsec)
        if len(result) > 0:
            row = result[0]
            return {
                'w1m': float(row['w1mpro']) if 'w1mpro' in row.colnames else None,
                'w2m': float(row['w2mpro']) if 'w2mpro' in row.colnames else None,
                'w3m': float(row['w3mpro']) if 'w3mpro' in row.colnames else None,
                'w4m': float(row['w4mpro']) if 'w4mpro' in row.colnames else None
            }
    except:
        pass
    return {'w1m': None, 'w2m': None, 'w3m': None, 'w4m': None}

def fetch_lightcurve_score(ra, dec):
    try:
        coord = SkyCoord(ra=ra*u.degree, dec=dec*u.degree, frame='icrs')
        obs = Observations.query_region(coord, radius=0.001*u.deg, dataproduct_type="timeseries")
        if len(obs) > 0:
            return 1.0
    except:
        return 0.0
    return 0.0

def fetch_live_gaia_stars(query: str) -> List[Star]:
    sql = f"""
    SELECT TOP 5
        source_id, ra, dec, parallax
    FROM gaiadr3.gaia_source
    WHERE source_id LIKE '%{query}%'
    """
    try:
        job = Gaia.launch_job_async(sql)
        df = job.get_results().to_pandas()
        stars = []
        for _, row in df.iterrows():
            parallax = row['parallax']
            distance = 1000.0 / parallax if parallax > 0 else -1.0
            wise = fetch_wise_data(row['ra'], row['dec'])
            lcurve = fetch_lightcurve_score(row['ra'], row['dec'])
            anomaly = 0.0
            if wise['w1m'] and wise['w4m']:
                if wise['w4m'] - wise['w1m'] < -1.0:
                    anomaly = 0.9
                elif wise['w4m'] - wise['w1m'] < -0.5:
                    anomaly = 0.6
                elif wise['w4m'] - wise['w1m'] < -0.2:
                    anomaly = 0.3
            suspicion = round((anomaly + lcurve) / 2, 2)
            stars.append(Star(
                name=f"Gaia-{row['source_id']}",
                distance=round(distance, 2),
                ra=round(row['ra'], 5),
                dec=round(row['dec'], 5),
                w1m=wise['w1m'],
                w2m=wise['w2m'],
                w3m=wise['w3m'],
                w4m=wise['w4m'],
                anomaly_score=anomaly,
                lightcurve_score=lcurve,
                suspicion_index=suspicion
            ))
        return stars
    except:
        return [Star(name="Error fetching Gaia/WISE data", distance=-1.0, ra=0.0, dec=0.0)]

@app.get("/gaia-search", response_model=List[Star])
async def search_stars(q: str = Query(..., description="Search term")):
    return fetch_live_gaia_stars(q)
