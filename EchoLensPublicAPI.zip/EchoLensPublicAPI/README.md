# EchoLens Public API

🚀 A public FastAPI service that scans stars for anomalies using Gaia, WISE, and TESS/Kepler.

## Features

- 🌌 Live star query by Gaia ID
- 🔥 Suspicion index = IR excess + light curve variability
- 🌐 REST API + simple frontend dashboard

## Setup

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 10000
```

## Example

Visit:
http://localhost:10000/static/index.html

Then query:
`/gaia-search?q=1234567890123456789`

---

Ready for deployment on Render or Railway.
